# NLP-
Course projects
Used the same code structure provided. Only modification in the template is the use of POS tags and a featurizers module to compute the features. Docstrings are provided for all functions to explain them. 
